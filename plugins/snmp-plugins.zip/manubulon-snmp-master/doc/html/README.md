This directory contains a copy of nagios.manubulon.com
with stripped binary files and removed french nagios docs.

# wget command

    wget --recursive --no-clobber --page-requisites --html-extension --convert-links --restrict-file-names=windows --domains nagios.manubulon.com --no-parent http://nagios.manubulon.com
