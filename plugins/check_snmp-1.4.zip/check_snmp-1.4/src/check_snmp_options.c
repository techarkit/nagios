/*
 *  check_snmp - a nagios plugin for checking snmp values
 *  Copyright (C) 2006  Bryan Cardillo
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifdef HAVE_CONFIG_H
#   include <config.h>
#endif

#ifdef HAVE_UNISTD_H
#   include <unistd.h>
#endif
#ifdef HAVE_GETOPT_H
#   include <getopt.h>
#endif

#ifdef HAVE_GETOPT_LONG
#   define GETOPTIONS(argc, argv, sopts, lopts, index) \
                getopt_long((argc), (argv), (sopts), (lopts), (index))
#else
#   define GETOPTIONS(argc, argv, sopts, lopts, index) \
                getopt((argc), (argv), (sopts))
#endif

#include "check_snmp.h"

void
check_snmp_usage(FILE *out)
{
    fprintf(out,
"usage: check_snmp [options]\n"
"options:\n"
"	-h,--help		print plugin usage\n"
"	-V,--version		print plugin version\n"
"	-v,--verbose		increase plugin output\n"
"	-l,--label		plugin output label\n"
"	-H,--hostname		hostname or ip address to check\n"
"	-C,--community		snmp community\n"
"	-o,--oid		snmp oid(s) to check\n"
"	-n,--next		use snmp getnext requests\n"
"	-w,--warning		warning threshold(s)\n"
"	-c,--critical		critical threshold(s)\n"
"	-s,--string		string match\n"
"	-r,--regex		regular expression match\n"
"	-i,--ignore-case	case insensitive string (or regex) match\n"
"	-e,--extended		use extended regular expressions\n"
"	-t,--timeout		connection timeout\n"
"	-R,--retries		connection retries\n"
    );
}

void
check_snmp_init_options(struct check_snmp_options *opts)
{
    opts->help = 0;
    opts->version = 0;
    opts->verbose = 0;
    opts->label = "SNMP";
    opts->host = NULL;
    opts->community = "public";
    opts->objects = "sysDescr.0";
    opts->warn = NULL;
    opts->crit = NULL;
    opts->smatch = NULL;
    opts->rmatch = NULL;
    opts->next = 0;
    opts->nocase = 0;
    opts->extended = 0;
    opts->timeout = -1;
    opts->retries = -1;
    opts->ids = NULL;
    opts->nids = 0;
    opts->type = CHECK_SNMP_SIMPLE;
    opts->message[0] = '\0';
}

static long
check_snmp_atoi(char *s, long d)
{
    long r;
    char *e;
    r = strtol(s, &e, 0);
    if (*s != '\0' && *e == '\0')
        return r;
    fprintf(stderr, "warning could not parse integer '%s'"
                " (using default=%ld)\n", s, d);
    return d;
}

int
check_snmp_get_options(struct check_snmp_options *opts, int argc, char **argv)
{
    int r = CHECK_SNMP_OK;

    while (1) {
        int c;
        int index = 0;
        static struct option longopts[] = {
            { "help", no_argument, 0, 'h' },
            { "version", no_argument, 0, 'V' },
            { "verbose", optional_argument, 0, 'v' },
            { "label", required_argument, 0, 'l' },
            { "hostname", required_argument, 0, 'H' },
            { "community", required_argument, 0, 'C' },
            { "oid", required_argument, 0, 'o' },
            { "next", no_argument, 0, 'n' },
            { "warning", required_argument, 0, 'w' },
            { "critical", required_argument, 0, 'c' },
            { "string", required_argument, 0, 's' },
            { "regex", required_argument, 0, 'r' },
            { "ignore-case", no_argument, 0, 'i' },
            { "extended", no_argument, 0, 'e' },
            { "timeout", required_argument, 0, 't' },
            { "retries", required_argument, 0, 'R' },
            { 0, 0, 0, 0 }
        };

        c = GETOPTIONS(argc, argv,
                "hVvl:H:C:o:nw:c:s:r:iet:R:", longopts, &index);
        if (c == -1)
            break;

        switch (c) {
            case 'h':
                opts->help = 1;
                break;
            case 'V':
                opts->version = 1;
                break;
            case 'v':
                opts->verbose = (optarg) ?
                    check_snmp_atoi(optarg, 1) : opts->verbose + 1;
                break;
            case 'l':
                opts->label = optarg;
                break;
            case 'H':
                opts->host = optarg;
                break;
            case 'C':
                opts->community = optarg;
                break;
            case 'o':
                opts->objects = optarg;
                break;
            case 'n':
                opts->next = 1;
                break;
            case 'w':
                opts->warn = optarg;
                break;
            case 'c':
                opts->crit = optarg;
                break;
            case 's':
                opts->smatch = optarg;
                break;
            case 'r':
                opts->rmatch = optarg;
                break;
            case 'i':
                opts->nocase = 1;
                break;
            case 'e':
                opts->extended = 1;
                break;
            case 't':
                opts->timeout = check_snmp_atoi(optarg, opts->timeout);
                break;
            case 'R':
                opts->retries = check_snmp_atoi(optarg, opts->retries);
                break;
            case '?':
                r = CHECK_SNMP_OTHER;
                break;
            default:
                fprintf(stderr, "warning unrecognized option (%c)\n", c);
                r = CHECK_SNMP_OTHER;
                break;
        }
    }

    if (optind < argc)
        r = CHECK_SNMP_OTHER;

    return r;
}

int
check_snmp_validate_options(struct check_snmp_options *opts)
{
    int r = CHECK_SNMP_OK;

    if (!opts->host) {
        fprintf(stderr, "hostname not specified\n\n");
        r = CHECK_SNMP_OTHER;
    } else if ((opts->warn || opts->crit) && opts->smatch) {
        fprintf(stderr, "interval checking and string matching"
                " are mutually exclusive\n\n");
        r = CHECK_SNMP_OTHER;
    } else if ((opts->warn || opts->crit) && opts->rmatch) {
        fprintf(stderr, "interval checking and regex matching"
                " are mutually exclusive\n\n");
        r = CHECK_SNMP_OTHER;
    } else if (opts->smatch && opts->rmatch) {
        fprintf(stderr, "string and regex matching"
                " are mutually exclusive\n\n");
        r = CHECK_SNMP_OTHER;
    }

    return r;
}

static void
check_snmp_process_intervals(struct check_snmp_options *opts)
{
    int i, j;
    char *c, *d, *next;
    char *intervals[2];

    /* stuff into an array for easy iteration */
    intervals[0] = opts->warn;
    intervals[1] = opts->crit;

    /* initialize limit types */
    for (i = 0; i < opts->nids; i++) {
        opts->ids[i].warn[CHECK_SNMP_LIMIT_TYPE] = CHECK_SNMP_LIMIT_NONE;
        opts->ids[i].crit[CHECK_SNMP_LIMIT_TYPE] = CHECK_SNMP_LIMIT_NONE;
    }

    for (i = 0; i < 2; i++) {
        for (c = intervals[i], j = 0; j < opts->nids && c; c = next, j++) {
            long *iv;

            if ((next = strchr(c, ',')))
                *next++ = '\0';

            if (strchr("!~", *c)) {
                opts->ids[j].invert = 1;
                c++;
            }

            iv = (i == 0) ? opts->ids[j].warn : opts->ids[j].crit;
            d = strchr(c, ':');
            if (d) {
                *d++ = '\0';
                iv[CHECK_SNMP_LIMIT_LOWER] = check_snmp_atoi(c, LONG_MAX);
                iv[CHECK_SNMP_LIMIT_TYPE] = CHECK_SNMP_LIMIT_LOWER;
                if (*d != '\0') {
                    iv[CHECK_SNMP_LIMIT_UPPER] = check_snmp_atoi(d, LONG_MIN);
                    iv[CHECK_SNMP_LIMIT_TYPE] = CHECK_SNMP_LIMIT_BOTH;
                    if (iv[CHECK_SNMP_LIMIT_LOWER] >
                            iv[CHECK_SNMP_LIMIT_UPPER]) {
                        long tmp = iv[CHECK_SNMP_LIMIT_LOWER];
                        iv[CHECK_SNMP_LIMIT_LOWER] = iv[CHECK_SNMP_LIMIT_UPPER];
                        iv[CHECK_SNMP_LIMIT_UPPER] = tmp;
                        opts->ids[j].invert = 1;
                    }
                }
            } else {
                iv[CHECK_SNMP_LIMIT_UPPER] = check_snmp_atoi(c, LONG_MIN);
                iv[CHECK_SNMP_LIMIT_TYPE] = (opts->ids[j].invert)
                        ? CHECK_SNMP_LIMIT_NEQ : CHECK_SNMP_LIMIT_UPPER;
            }
        }
    }
}

static void
check_snmp_process_strings(struct check_snmp_options *opts)
{
    int i;
    char *c, *next;

    for (c = opts->smatch, i = 0; i < opts->nids && c; c = next, i++) {
        if ((next = strchr(c, ',')))
            *next++ = '\0';

        if (strchr("!~", *c)) {
            opts->ids[i].invert = 1;
            c++;
        }

        opts->ids[i].smatch = c;
    }
}

static void
check_snmp_process_regexes(struct check_snmp_options *opts)
{
    int i, r;
    char *c, *next = NULL;
    int flags = REG_NOSUB | REG_NEWLINE |
                    ((opts->nocase) ? REG_ICASE : 0) |
                    ((opts->extended) ? REG_EXTENDED : 0);

    for (c = opts->rmatch, i = 0; i < opts->nids; c = next, i++) {
        if (c && (next = strchr(c, ',')))
            *next++ = '\0';

        if (strchr("!~", *c)) {
            opts->ids[i].invert = 1;
            c++;
        }

        if ((r = regcomp(&opts->ids[i].rmatch, (c) ? c : "", flags)))
            opts->ids[i].rerr = r;
    }
}

int
check_snmp_process_options(struct check_snmp_options *opts)
{
    int i;
    char *c, *next;

    /* count objects */
    for (c = opts->objects, i = 0; c; c = next, i++)
        if ((next = strchr(c, ',')))
            next++;

    /* allocate check_snmp_oid structures */
    opts->nids = i;
    opts->ids = malloc(sizeof(struct check_snmp_oid) * opts->nids);
    if (!opts->ids)
        return -ENOMEM;
    memset(opts->ids, 0, sizeof(struct check_snmp_oid) * opts->nids);

    /* init check_snmp_oid structures */
    for (c = opts->objects, i = 0; i < opts->nids && c; c = next, i++) {
        if ((next = strchr(c, ',')))
            *next++ = '\0';
        opts->ids[i].name = c;
    }

    if (opts->warn || opts->crit) {
        check_snmp_process_intervals(opts);
        opts->type = CHECK_SNMP_INTERVAL;
    } else if (opts->smatch) {
        check_snmp_process_strings(opts);
        opts->type = CHECK_SNMP_STRING;
    } else if (opts->rmatch) {
        check_snmp_process_regexes(opts);
        opts->type = CHECK_SNMP_REGEX;
    }

    return CHECK_SNMP_OK;
}

void
check_snmp_free_options(struct check_snmp_options *opts)
{
    int i;

    for (i = 0; i < opts->nids; i++)
        regfree(&opts->ids[i].rmatch);

    free(opts->ids);
}
