/*
 *  check_snmp - a nagios plugin for checking snmp values
 *  Copyright (C) 2006  Bryan Cardillo
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifdef HAVE_CONFIG_H
#   include <config.h>
#endif

#include "check_snmp.h"

static int check_snmp(struct check_snmp_options *);
static void check_snmp_print_message(struct check_snmp_options *, int);
static int check_snmp_response(struct check_snmp_options *, struct snmp_pdu *);
static const char *check_snmp_rval_to_string(int);

int
main(int argc, char **argv)
{
    int r = CHECK_SNMP_UNKNOWN;
    struct check_snmp_options opts;

    check_snmp_init_options(&opts);
    if (check_snmp_get_options(&opts, argc, argv)) {
        check_snmp_usage(stderr);
    } else if (opts.help) {
        check_snmp_usage(stdout);
        r = CHECK_SNMP_OK;
    } else if (opts.version) {
        printf(PACKAGE_STRING"\n");
        r = CHECK_SNMP_OK;
    } else if (check_snmp_validate_options(&opts)
            || check_snmp_process_options(&opts)) {
        check_snmp_usage(stderr);
    } else {
        r = check_snmp(&opts);
    }
    check_snmp_free_options(&opts);

    return r;
}

static int
check_snmp(struct check_snmp_options *opts)
{
    int i, r = CHECK_SNMP_UNKNOWN;
    struct snmp_session init, *session;
    struct snmp_pdu *pdu, *response;
    oid *o, objid[MAX_OID_LEN];
    size_t objidlen = MAX_OID_LEN;

    snmp_disable_log();
    if (opts->verbose)
        snmp_enable_stderrlog();
    init_snmp(PACKAGE_NAME);
    snmp_sess_init(&init);

    init.peername = opts->host;
    init.version = SNMP_VERSION_2c;
    init.community = opts->community;
    init.community_len = strlen(init.community);
    if (opts->timeout >= 0)
        init.timeout = opts->timeout;
    if (opts->retries >= 0)
        init.retries = opts->retries;

    session = snmp_open(&init);
    if (!session) {
        sprintf(opts->message, "%.*s",
                CHECK_SNMP_MSG_LEN, snmp_api_errstring(init.s_snmp_errno));
        check_snmp_print_message(opts, CHECK_SNMP_CRITICAL);
        return CHECK_SNMP_CRITICAL;
    }

    pdu = snmp_pdu_create((opts->next) ? SNMP_MSG_GETNEXT : SNMP_MSG_GET);

    for (i = 0; i < opts->nids; i++) {
        o = snmp_parse_oid(opts->ids[i].name, objid, &objidlen);
        if (!o) {
            sprintf(opts->message, "%.*s",
                    CHECK_SNMP_MSG_LEN, snmp_api_errstring(snmp_errno));
            check_snmp_print_message(opts, CHECK_SNMP_UNKNOWN);
            return CHECK_SNMP_UNKNOWN;
        }
        snmp_add_null_var(pdu, objid, objidlen);
    }

    r = snmp_synch_response(session, pdu, &response);
    switch (r) {
        case STAT_SUCCESS:
            switch (response->errstat) {
                case SNMP_ERR_NOERROR:
                    r = check_snmp_response(opts, response);
                    break;
                default:
                    sprintf(opts->message, "%.*s",
                            CHECK_SNMP_MSG_LEN,
                            snmp_api_errstring(response->errstat));
                    r = CHECK_SNMP_CRITICAL;
                    break;
            }
            break;
        case STAT_ERROR:
            sprintf(opts->message, "%.*s", 
                    CHECK_SNMP_MSG_LEN, "request error");
            r = CHECK_SNMP_CRITICAL;
            break;
        case STAT_TIMEOUT:
            sprintf(opts->message, "%.*s", 
                    CHECK_SNMP_MSG_LEN, "request timeout");
            r = CHECK_SNMP_CRITICAL;
            break;
        default:
            sprintf(opts->message, "%.*s", 
                    CHECK_SNMP_MSG_LEN, "unknown network error");
            r = CHECK_SNMP_CRITICAL;
            break;
    }
    if (response)
        snmp_free_pdu(response);
    snmp_close(session);

    check_snmp_print_message(opts, r);
    return r;
}

static void
check_snmp_print_message(struct check_snmp_options *opts, int r)
{
    printf("%s %s - %s\n", opts->label,
            check_snmp_rval_to_string(r), opts->message);
}

static const char *
check_snmp_rval_to_string(int rval)
{
    switch (rval) {
        case CHECK_SNMP_OK:
            return "OK";
        case CHECK_SNMP_WARNING:
            return "WARNING";
        case CHECK_SNMP_CRITICAL:
            return "CRITICAL";
        default:
            return "UNKNOWN";
    }
}

static int
check_snmp_response(struct check_snmp_options *opts, struct snmp_pdu *response)
{
    int r = CHECK_SNMP_OK;
    struct variable_list *vars = response->variables;
    switch (opts->type) {
        case CHECK_SNMP_INTERVAL:
            r = check_snmp_intervals(opts, vars);
            break;
        case CHECK_SNMP_STRING:
            r = check_snmp_strings(opts, vars);
            break;
        case CHECK_SNMP_REGEX:
            r = check_snmp_regexes(opts, vars);
            break;
        default:
            r = check_snmp_simple(opts, vars);
            break;
    }
    return r;
}

int
check_snmp_var_type(struct variable_list *v)
{
    switch (v->type) {
        case SNMP_NOSUCHOBJECT:
        case SNMP_NOSUCHINSTANCE:
            return CHECK_SNMP_WARNING;
        default:
            return CHECK_SNMP_OK;
    }
}

char *
check_snmp_get_value(char *value, int type)
{
    int i, cut = 1;
    char *s, *t;

    if (type & ASN_APPLICATION)
        cut++;

    for (i = 0, s = value; i < cut && (t = strchr(s, ':')); i++, s = t)
        while (isspace(*++t)) ;

    return s;
}
