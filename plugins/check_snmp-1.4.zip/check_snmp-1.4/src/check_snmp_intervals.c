/*
 *  check_snmp - a nagios plugin for checking snmp values
 *  Copyright (C) 2006  Bryan Cardillo
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifdef HAVE_CONFIG_H
#   include <config.h>
#endif

#include "check_snmp.h"

int
check_snmp_intervals(
        struct check_snmp_options *opts, struct variable_list *vars)
{
    int i, j, r = CHECK_SNMP_OK;
    long *warn, *crit;
    struct variable_list *v;
    char *c = opts->message;
    char buf[CHECK_SNMP_MSG_LEN];
    long value;

    for (v = vars, i = 0; v; v = v->next_variable, i++) {
        warn = opts->ids[i].warn;
        crit = opts->ids[i].crit;
        j = check_snmp_var_type(v);

        if (snprint_value(buf, CHECK_SNMP_MSG_LEN,
                            v->name, v->name_length, v) < 0)
            c += sprintf(c, "%.*s",
                        CHECK_SNMP_MSG_LEN - (c - opts->message), "(unknown)");

        switch (v->type) {
            case ASN_INTEGER:
            case ASN_INTEGER | ASN_APPLICATION:
                value = *v->val.integer;
                /* check critical thresholds */
                switch (crit[CHECK_SNMP_LIMIT_TYPE]) {
                    case CHECK_SNMP_LIMIT_BOTH:
                        if (opts->ids[i].invert ^
                                !(crit[CHECK_SNMP_LIMIT_LOWER] <= value &&
                                        value <= crit[CHECK_SNMP_LIMIT_UPPER]))
                            j = MAX(j, CHECK_SNMP_CRITICAL);
                        break;
                    case CHECK_SNMP_LIMIT_LOWER:
                        if (opts->ids[i].invert ^
                                !(crit[CHECK_SNMP_LIMIT_LOWER] <= value))
                            j = MAX(j, CHECK_SNMP_CRITICAL);
                        break;
                    case CHECK_SNMP_LIMIT_UPPER:
                        if (opts->ids[i].invert ^
                                !(value <= crit[CHECK_SNMP_LIMIT_UPPER]))
                            j = MAX(j, CHECK_SNMP_CRITICAL);
                        break;
                    case CHECK_SNMP_LIMIT_NEQ:
                        if (value != crit[CHECK_SNMP_LIMIT_UPPER])
                            j = MAX(j, CHECK_SNMP_WARNING);
                        break;
                }
                /* check warning thresholds */
                switch (warn[CHECK_SNMP_LIMIT_TYPE]) {
                    case CHECK_SNMP_LIMIT_BOTH:
                        if (opts->ids[i].invert ^
                                !(warn[CHECK_SNMP_LIMIT_LOWER] <= value &&
                                        value <= warn[CHECK_SNMP_LIMIT_UPPER]))
                            j = MAX(j, CHECK_SNMP_WARNING);
                        break;
                    case CHECK_SNMP_LIMIT_LOWER:
                        if (opts->ids[i].invert ^
                                !(warn[CHECK_SNMP_LIMIT_LOWER] <= value))
                            j = MAX(j, CHECK_SNMP_WARNING);
                        break;
                    case CHECK_SNMP_LIMIT_UPPER:
                        if (opts->ids[i].invert ^
                                !(value <= warn[CHECK_SNMP_LIMIT_UPPER]))
                            j = MAX(j, CHECK_SNMP_WARNING);
                        break;
                    case CHECK_SNMP_LIMIT_NEQ:
                        if (value != warn[CHECK_SNMP_LIMIT_UPPER])
                            j = MAX(j, CHECK_SNMP_WARNING);
                        break;
                }
                break;
            default: /* type unsupported for interval checking */
                j = MAX(j, CHECK_SNMP_WARNING);
                break;
        }

        if (opts->message < c && c < opts->message + CHECK_SNMP_MSG_LEN - 1)
            *c++ = ' ';

        c += sprintf(c, (j == CHECK_SNMP_OK) ? "%.*s" : "*%.*s*",
                    CHECK_SNMP_MSG_LEN - (c - opts->message),
                    check_snmp_get_value(buf, v->type));
        r = MAX(r, j);
    }

    return r;
}
