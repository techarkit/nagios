/*
 *  check_snmp - a nagios plugin for checking snmp values
 *  Copyright (C) 2006  Bryan Cardillo
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifdef HAVE_CONFIG_H
#   include <config.h>
#endif

#include "check_snmp.h"

int
check_snmp_regexes(
        struct check_snmp_options *opts, struct variable_list *vars)
{
    int i, j, r = CHECK_SNMP_OK;
    struct variable_list *v;
    char *c = opts->message;
    char buf[CHECK_SNMP_MSG_LEN];

    for (i = 0, v = vars; i < opts->nids && v; i++, v = v->next_variable) {
        j = check_snmp_var_type(v);

        if (snprint_value(buf, CHECK_SNMP_MSG_LEN,
                            v->name, v->name_length, v) < 0)
            c += sprintf(c, "%.*s",
                        CHECK_SNMP_MSG_LEN - (c - opts->message), "(unknown)");

        if (opts->ids[i].invert ^
                regexec(&opts->ids[i].rmatch, buf, 0, NULL, 0))
            j = MAX(j, CHECK_SNMP_CRITICAL);

        if (opts->message < c && c < opts->message + CHECK_SNMP_MSG_LEN - 1)
            *c++ = ' ';

        c += sprintf(c, (j == CHECK_SNMP_OK) ? "%.*s" : "*%.*s*",
                    CHECK_SNMP_MSG_LEN - (c - opts->message),
                    check_snmp_get_value(buf, v->type));
        r = MAX(r, j);
    }

    return r;
}
