#ifndef __CHECK_SNMP_H
#define __CHECK_SNMP_H  1
#ifdef HAVE_CONFIG_H
#   include <config.h>
#endif

#ifdef STDC_HEADERS
#   include <ctype.h>
#   include <errno.h>
#   include <stdio.h>
#   include <stdlib.h>
#   include <string.h>
#endif
#ifdef HAVE_SYS_TYPES_H
#   include <sys/types.h>
#endif
#ifdef HAVE_REGEX_H
#   include <regex.h>
#endif

#ifdef HAVE_NET_SNMP_CONFIG_H
#   undef PACKAGE_BUGREPORT
#   undef PACKAGE_NAME
#   undef PACKAGE_STRING
#   undef PACKAGE_TARNAME
#   undef PACKAGE_VERSION

#   include <net-snmp-config.h>
#   include <net-snmp-includes.h>

#   undef PACKAGE_BUGREPORT
#   undef PACKAGE_NAME
#   undef PACKAGE_STRING
#   undef PACKAGE_TARNAME
#   undef PACKAGE_VERSION

#   ifdef HAVE_CONFIG_H
#       include <config.h>
#   endif
#endif

#define CHECK_SNMP_OK               0
#define CHECK_SNMP_WARNING          1
#define CHECK_SNMP_CRITICAL         2
#define CHECK_SNMP_UNKNOWN          3
#define CHECK_SNMP_OTHER            4

#define CHECK_SNMP_SIMPLE           0x1
#define CHECK_SNMP_INTERVAL         0x2
#define CHECK_SNMP_STRING           0x4
#define CHECK_SNMP_REGEX            0x8

#define CHECK_SNMP_LIMIT_LOWER      0
#define CHECK_SNMP_LIMIT_UPPER      1
#define CHECK_SNMP_LIMIT_BOTH       2
#define CHECK_SNMP_LIMIT_NEQ        3
#define CHECK_SNMP_LIMIT_NONE       4
#define CHECK_SNMP_LIMIT_TYPE       2
#define CHECK_SNMP_LIMIT_STATUS     3

#define CHECK_SNMP_MSG_LEN          512

#ifndef MAX
#   define MAX(a,b) ((a) > (b)) ? (a) : (b)
#endif

struct check_snmp_options {
    int help;
    int version;
    long verbose;
    char *label;
    char *host;
    char *community;
    char *objects;
    char *warn;
    char *crit;
    char *smatch;
    char *rmatch;
    int next;
    int nocase;
    int extended;
    long timeout;
    long retries;
    struct check_snmp_oid *ids;
    size_t nids;
    int type;
    char message[CHECK_SNMP_MSG_LEN];
};

struct check_snmp_oid {
    char *name;
    long warn[4];
    long crit[4];
    char *smatch;
    regex_t rmatch;
    int rerr;
    int invert;
};

void check_snmp_init_options(struct check_snmp_options *);
int check_snmp_get_options(struct check_snmp_options *, int, char **);
int check_snmp_validate_options(struct check_snmp_options *);
int check_snmp_process_options(struct check_snmp_options *);
void check_snmp_free_options(struct check_snmp_options *);
void check_snmp_usage(FILE *);

int check_snmp_var_type(struct variable_list *);
int check_snmp_intervals(struct check_snmp_options *, struct variable_list *);
int check_snmp_strings(struct check_snmp_options *, struct variable_list *);
int check_snmp_regexes(struct check_snmp_options *, struct variable_list *);
int check_snmp_simple(struct check_snmp_options *, struct variable_list *);
char *check_snmp_get_value(char *, int);

#endif
